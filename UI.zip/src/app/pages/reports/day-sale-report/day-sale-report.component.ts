import { Component } from '@angular/core';

@Component({
  selector: 'app-day-sale-report',
  templateUrl: './day-sale-report.component.html',
  styleUrls: ['./day-sale-report.component.css']
})
export class DaySaleReportComponent {

}
